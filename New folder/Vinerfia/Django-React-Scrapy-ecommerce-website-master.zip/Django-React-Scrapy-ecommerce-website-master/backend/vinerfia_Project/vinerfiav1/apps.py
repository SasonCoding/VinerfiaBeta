from django.apps import AppConfig


class Vinerfiav1Config(AppConfig):
    name = 'vinerfiav1'
