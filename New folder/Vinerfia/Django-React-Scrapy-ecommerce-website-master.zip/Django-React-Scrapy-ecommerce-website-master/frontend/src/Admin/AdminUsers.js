import React, { Component } from 'react'



export const AdminUsers = () =>
{
    return <h1>Users</h1>
}