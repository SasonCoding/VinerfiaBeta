import React from 'react'



const ErrorPage = () =>
{
    return <div align='center'>
                <h1>Server is Down Sorry or URL is Wrong</h1>
            </div>
}


export default ErrorPage;