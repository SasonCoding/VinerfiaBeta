import { createContext } from 'react';
    
    export const OrderDetailsContext = createContext();
    